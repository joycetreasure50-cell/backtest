document.addEventListener('DOMContentLoaded', () => {
  const contactForm = document.querySelector('.contact-form');

  if (contactForm) {
    contactForm.addEventListener('submit', async (event) => {
      // Prevent the default browser page reload
      event.preventDefault();

      const submitButton = contactForm.querySelector('.btn-send');
      
      // Extract input values matching the form fields
      const formData = {
        name: contactForm.querySelector('input[name="name"]').value,
        email: contactForm.querySelector('input[name="email"]').value,
        subject: contactForm.querySelector('input[name="subject"]').value,
        message: contactForm.querySelector('textarea[name="message"]').value
      };

      try {
        // UI feedback during request
        submitButton.disabled = true;
        submitButton.textContent = 'Sending...';

        // Perform the POST request
        const response = await fetch('https://your-api-endpoint.com/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(formData)
        });

        if (!response.ok) {
          throw new Error(`Server returned status: ${response.status}`);
        }

        const result = await response.json();
        
        // Handle success
        alert('Your message has been sent successfully!');
        contactForm.reset();

      } catch (error) {
        // Handle error
        console.error('Error submitting form:', error);
        alert('Failed to send message. Please try again later.');

      } finally {
        // Reset button state
        submitButton.disabled = false;
        submitButton.textContent = 'Send';
      }
    });
  }
});